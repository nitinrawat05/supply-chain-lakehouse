# ============================================================
# dbt Project: supply_chain_dbt
# ============================================================
# Run: dbt run --profiles-dir . --target databricks
# Test: dbt test
# Docs: dbt docs generate && dbt docs serve
# ============================================================

# FILE: dbt_project.yml
# ============================================================
# name: supply_chain
# version: '1.0.0'
# config-version: 2
# profile: supply_chain
#
# model-paths: ["models"]
# test-paths: ["tests"]
# docs-paths: ["docs"]
#
# models:
#   supply_chain:
#     staging:
#       +schema: supply_chain_silver
#       +materialized: view
#     marts:
#       +schema: supply_chain_gold
#       +materialized: table
#       +file_format: delta

# ============================================================
# FILE: models/staging/stg_purchase_orders.sql
# ============================================================
