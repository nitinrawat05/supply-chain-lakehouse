-- ============================================================
-- dbt Model: marts/gold_supplier_scorecard.sql
-- Description: Supplier KPI scorecard with composite score
-- ============================================================

WITH purchase_orders AS (
    SELECT * FROM {{ ref('stg_purchase_orders') }}
),

po_lines AS (
    SELECT * FROM {{ ref('stg_po_line_items') }}
),

suppliers AS (
    SELECT * FROM {{ ref('stg_suppliers') }}
),

po_agg AS (
    SELECT
        po.supplier_id,
        COUNT(po.po_id)                                          AS total_pos,
        SUM(po.total_amount_usd)                                 AS total_spend_usd,
        AVG(po.total_amount_usd)                                 AS avg_po_value_usd,
        SUM(CASE WHEN po.status = 'Delivered' THEN 1 ELSE 0 END) AS delivered_pos,
        SUM(CASE WHEN po.is_late = TRUE THEN 1 ELSE 0 END)      AS late_pos,
        AVG(po.delay_days)                                       AS avg_delay_days,
        SUM(CASE WHEN po.quality_check_passed = FALSE THEN 1 ELSE 0 END) AS quality_failures,
        AVG(pol.fill_rate_pct)                                   AS avg_fill_rate_pct
    FROM purchase_orders po
    LEFT JOIN po_lines pol ON po.po_id = pol.po_id
    GROUP BY 1
),

scored AS (
    SELECT
        s.supplier_id,
        s.supplier_name,
        s.country,
        s.category,
        s.rating,
        s.lead_time_days,
        s.payment_terms,
        a.total_pos,
        a.total_spend_usd,
        a.avg_po_value_usd,
        a.avg_delay_days,
        a.avg_fill_rate_pct,
        a.quality_failures,

        ROUND(
            (a.delivered_pos - a.late_pos) * 100.0 / NULLIF(a.delivered_pos, 0),
            2
        ) AS on_time_delivery_rate,

        ROUND(
            (a.total_pos - a.quality_failures) * 100.0 / NULLIF(a.total_pos, 0),
            2
        ) AS quality_pass_rate,

        -- Composite Supplier Score (weighted)
        ROUND(
            (ROUND((a.delivered_pos - a.late_pos) * 100.0 / NULLIF(a.delivered_pos, 0), 2) * 0.35) +
            (ROUND((a.total_pos - a.quality_failures) * 100.0 / NULLIF(a.total_pos, 0), 2) * 0.35) +
            (COALESCE(a.avg_fill_rate_pct, 0) * 0.30),
            2
        ) AS supplier_score

    FROM suppliers s
    LEFT JOIN po_agg a ON s.supplier_id = a.supplier_id
)

SELECT
    *,
    CASE
        WHEN supplier_score >= 85 THEN 'A - Strategic'
        WHEN supplier_score >= 70 THEN 'B - Preferred'
        WHEN supplier_score >= 55 THEN 'C - Approved'
        ELSE                            'D - Review'
    END AS supplier_tier,

    -- Rank within category
    RANK() OVER (
        PARTITION BY category
        ORDER BY supplier_score DESC
    ) AS rank_in_category,

    CURRENT_TIMESTAMP() AS _dbt_updated_at

FROM scored
