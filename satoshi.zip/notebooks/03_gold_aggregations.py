# Databricks notebook source
# MAGIC %md
# MAGIC # 🥇 Gold Layer — Business Aggregations (Star Schema)
# MAGIC **Pipeline:** Supply Chain Lakehouse  
# MAGIC **Layer:** Gold (Analytics-ready, Star Schema)  
# MAGIC **Reads from:** supply_chain_silver  
# MAGIC **Writes to:** supply_chain_gold  
# MAGIC **Consumed by:** Power BI / Tableau via DirectQuery

# COMMAND ----------
SILVER_DB = "supply_chain_silver"
GOLD_DB   = "supply_chain_gold"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {GOLD_DB}")
spark.sql(f"USE {GOLD_DB}")
print(f"✓ Database ready: {GOLD_DB}")

# COMMAND ----------
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from delta.tables import DeltaTable

def write_gold(df, table_name: str, partition_col: str = None):
    target = f"{GOLD_DB}.{table_name}"
    df = df.withColumn("_gold_updated_at", F.current_timestamp())
    
    writer = df.write.format("delta").mode("overwrite").option("overwriteSchema", "true")
    if partition_col:
        writer = writer.partitionBy(partition_col)
    writer.saveAsTable(target)
    
    count = spark.table(target).count()
    print(f"✓ {target}: {count:,} rows")

# Load Silver tables
dim_suppliers  = spark.table(f"{SILVER_DB}.dim_suppliers")
dim_warehouses = spark.table(f"{SILVER_DB}.dim_warehouses")
dim_carriers   = spark.table(f"{SILVER_DB}.dim_carriers")
dim_products   = spark.table(f"{SILVER_DB}.dim_products")
fact_po        = spark.table(f"{SILVER_DB}.fact_purchase_orders")
fact_pol       = spark.table(f"{SILVER_DB}.fact_po_line_items")
fact_shp       = spark.table(f"{SILVER_DB}.fact_shipments")
fact_so        = spark.table(f"{SILVER_DB}.fact_sales_orders")
fact_sol       = spark.table(f"{SILVER_DB}.fact_so_line_items")
fact_inv       = spark.table(f"{SILVER_DB}.fact_inventory")

print("✓ Silver tables loaded")

# COMMAND ----------
# MAGIC %md ## 1. Date Dimension

# COMMAND ----------
from pyspark.sql.types import *

# Generate date dimension 2022-2025
date_df = spark.sql("""
    SELECT sequence(to_date('2022-01-01'), to_date('2025-12-31'), interval 1 day) AS date_array
""").select(F.explode("date_array").alias("date"))

dim_date = (date_df
    .withColumn("date_key",        F.date_format("date", "yyyyMMdd").cast(IntegerType()))
    .withColumn("year",            F.year("date"))
    .withColumn("quarter",         F.quarter("date"))
    .withColumn("month",           F.month("date"))
    .withColumn("month_name",      F.date_format("date", "MMMM"))
    .withColumn("week",            F.weekofyear("date"))
    .withColumn("day_of_week",     F.dayofweek("date"))
    .withColumn("day_name",        F.date_format("date", "EEEE"))
    .withColumn("is_weekend",      F.dayofweek("date").isin([1, 7]))
    .withColumn("year_month",      F.date_format("date", "yyyy-MM"))
    .withColumn("year_quarter",    F.concat(F.year("date"), F.lit("-Q"), F.quarter("date")))
    .withColumn("fiscal_year",
        F.when(F.month("date") >= 7, F.year("date") + 1).otherwise(F.year("date")))
)

write_gold(dim_date, "dim_date")

# COMMAND ----------
# MAGIC %md ## 2. Revenue & Orders Summary (Monthly)

# COMMAND ----------
monthly_revenue = (fact_so
    .groupBy("order_year", "order_month", "order_quarter", "warehouse_id", "sales_channel")
    .agg(
        F.count("so_id").alias("total_orders"),
        F.sum("total_amount_usd").alias("gross_revenue_usd"),
        F.sum("net_amount_usd").alias("net_revenue_usd"),
        F.avg("total_amount_usd").alias("avg_order_value_usd"),
        F.sum(F.when(F.col("on_time_delivery") == True, 1).otherwise(0)).alias("on_time_orders"),
        F.sum(F.when(F.col("return_flag") == True, 1).otherwise(0)).alias("returned_orders"),
        F.avg("delay_days").alias("avg_delay_days"),
        F.sum("discount_pct").alias("total_discount_given"),
    )
    .withColumn("otd_rate_pct",
        F.round(F.col("on_time_orders") / F.col("total_orders") * 100, 2))
    .withColumn("return_rate_pct",
        F.round(F.col("returned_orders") / F.col("total_orders") * 100, 2))
    .withColumn("order_year_month",
        F.concat(F.col("order_year"), F.lit("-"), F.lpad(F.col("order_month").cast("string"), 2, "0")))
)

write_gold(monthly_revenue, "gold_monthly_revenue", "order_year")

# COMMAND ----------
# MAGIC %md ## 3. Supplier Performance Scorecard

# COMMAND ----------
supplier_performance = (fact_po
    .join(dim_suppliers, "supplier_id")
    .join(fact_pol, "po_id", "left")
    .groupBy(
        "supplier_id", "supplier_name", "country", "category",
        "rating", "lead_time_days", "payment_terms"
    )
    .agg(
        F.count("po_id").alias("total_pos"),
        F.sum("total_amount_usd").alias("total_spend_usd"),
        F.avg("total_amount_usd").alias("avg_po_value_usd"),
        F.sum(F.when(F.col("status") == "Delivered", 1).otherwise(0)).alias("delivered_pos"),
        F.sum(F.when(F.col("is_late") == True, 1).otherwise(0)).alias("late_pos"),
        F.avg("delay_days").alias("avg_delay_days"),
        F.sum(F.when(F.col("quality_check_passed") == False, 1).otherwise(0)).alias("quality_failures"),
        F.avg("fill_rate_pct").alias("avg_fill_rate_pct"),
    )
    .withColumn("on_time_delivery_rate",
        F.round((F.col("delivered_pos") - F.col("late_pos")) / F.col("delivered_pos") * 100, 2))
    .withColumn("quality_pass_rate",
        F.round((F.col("total_pos") - F.col("quality_failures")) / F.col("total_pos") * 100, 2))
    # Composite supplier score (weighted)
    .withColumn("supplier_score",
        F.round(
            (F.col("on_time_delivery_rate") * 0.35) +
            (F.col("quality_pass_rate") * 0.35) +
            (F.col("avg_fill_rate_pct") * 0.30),
        2))
    .withColumn("supplier_tier",
        F.when(F.col("supplier_score") >= 85, "A - Strategic")
         .when(F.col("supplier_score") >= 70, "B - Preferred")
         .when(F.col("supplier_score") >= 55, "C - Approved")
         .otherwise("D - Review"))
)

write_gold(supplier_performance, "gold_supplier_scorecard")

# COMMAND ----------
# MAGIC %md ## 4. Warehouse Inventory Health

# COMMAND ----------
# Get latest snapshot per warehouse/product
window_latest = Window.partitionBy("warehouse_id", "product_id").orderBy(F.desc("snapshot_date"))

latest_inv = (fact_inv
    .withColumn("rn", F.row_number().over(window_latest))
    .filter(F.col("rn") == 1)
    .drop("rn")
)

warehouse_inventory = (latest_inv
    .join(dim_products, "product_id")
    .join(dim_warehouses, "warehouse_id")
    .withColumn("inventory_value_usd",
        F.round(F.col("quantity_on_hand") * F.col("unit_cost_usd"), 2))
    .withColumn("stock_status",
        F.when(F.col("quantity_available") <= 0, "Out of Stock")
         .when(F.col("quantity_available") < F.col("reorder_point"), "Low Stock")
         .when(F.col("quantity_available") > F.col("reorder_point") * 3, "Overstock")
         .otherwise("Healthy"))
    .withColumn("reorder_needed",
        F.col("quantity_on_hand") < F.col("reorder_point"))
    .select(
        "warehouse_id", "city", "region", "country",
        "product_id", "product_name", "category", "sku",
        "snapshot_date", "quantity_on_hand", "quantity_reserved",
        "quantity_available", "quantity_in_transit",
        "reorder_point", "reorder_qty", "reorder_needed",
        "unit_cost_usd", "inventory_value_usd",
        "stock_status", "days_since_restock"
    )
)

write_gold(warehouse_inventory, "gold_inventory_health", "warehouse_id")

# COMMAND ----------
# MAGIC %md ## 5. Carrier Performance

# COMMAND ----------
carrier_performance = (fact_shp
    .join(dim_carriers, "carrier_id")
    .groupBy("carrier_id", "name", "type", "reliability_score")
    .agg(
        F.count("shipment_id").alias("total_shipments"),
        F.sum("shipping_cost_usd").alias("total_shipping_cost_usd"),
        F.avg("shipping_cost_usd").alias("avg_shipping_cost_usd"),
        F.avg("actual_transit_days").alias("avg_transit_days"),
        F.sum(F.when(F.col("is_on_time") == True, 1).otherwise(0)).alias("on_time_shipments"),
        F.sum(F.when(F.col("damage_reported") == True, 1).otherwise(0)).alias("damaged_shipments"),
        F.sum(F.when(F.col("customs_cleared") == False, 1).otherwise(0)).alias("customs_held"),
        F.sum("weight_kg").alias("total_weight_kg"),
        F.sum("volume_cbm").alias("total_volume_cbm"),
    )
    .withColumn("otd_rate_pct",
        F.round(F.col("on_time_shipments") / F.col("total_shipments") * 100, 2))
    .withColumn("damage_rate_pct",
        F.round(F.col("damaged_shipments") / F.col("total_shipments") * 100, 2))
    .withColumn("cost_per_kg",
        F.round(F.col("total_shipping_cost_usd") / F.col("total_weight_kg"), 2))
)

write_gold(carrier_performance, "gold_carrier_performance")

# COMMAND ----------
# MAGIC %md ## 6. Product Revenue Analysis

# COMMAND ----------
product_revenue = (fact_sol
    .join(fact_so.select("so_id", "order_date", "order_year", "order_month", "order_quarter",
                          "on_time_delivery", "return_flag", "sales_channel"), "so_id")
    .join(dim_products, "product_id")
    .groupBy(
        "product_id", "product_name", "category", "sku",
        "unit_cost_usd", "unit_price_usd", "gross_margin_pct",
        "order_year", "order_quarter"
    )
    .agg(
        F.sum("quantity").alias("total_units_sold"),
        F.sum("total_price_usd").alias("gross_revenue_usd"),
        F.sum("net_revenue_usd").alias("net_revenue_usd"),
        F.count("so_id").alias("order_count"),
        F.avg("unit_price_usd").alias("avg_selling_price"),
    )
    .withColumn("total_cogs_usd",
        F.round(F.col("total_units_sold") * F.col("unit_cost_usd"), 2))
    .withColumn("gross_profit_usd",
        F.round(F.col("net_revenue_usd") - F.col("total_cogs_usd"), 2))
)

write_gold(product_revenue, "gold_product_revenue", "order_year")

# COMMAND ----------
# MAGIC %md ## 7. End-to-End Order Fulfillment View

# COMMAND ----------
fulfillment = (fact_so
    .join(dim_warehouses.select("warehouse_id", "city", "region", "country"), "warehouse_id")
    .join(dim_carriers.select("carrier_id", F.col("name").alias("carrier_name"), "type"), "carrier_id")
    .select(
        "so_id", "customer_id", "order_date", "order_year", "order_month",
        "order_quarter", "promised_delivery_date", "actual_delivery_date",
        "status", "priority", "sales_channel",
        "total_amount_usd", "net_amount_usd", "discount_pct",
        "on_time_delivery", "delay_days", "return_flag",
        "warehouse_id", "city", "region", "country",
        "carrier_id", "carrier_name", "type"
    )
    .withColumn("fulfillment_status",
        F.when(F.col("return_flag") == True, "Returned")
         .when(F.col("on_time_delivery") == True, "On Time")
         .when(F.col("delay_days") <= 3, "Minor Delay")
         .when(F.col("delay_days") <= 7, "Moderate Delay")
         .otherwise("Critical Delay"))
    .withColumn("order_size_bucket",
        F.when(F.col("total_amount_usd") < 1000, "Small")
         .when(F.col("total_amount_usd") < 10000, "Medium")
         .when(F.col("total_amount_usd") < 50000, "Large")
         .otherwise("Enterprise"))
)

write_gold(fulfillment, "gold_order_fulfillment", "order_year")

# COMMAND ----------
# MAGIC %md ## 8. KPI Summary Table (for Dashboard Cards)

# COMMAND ----------
kpis = spark.sql(f"""
SELECT
    -- Revenue KPIs
    ROUND(SUM(net_amount_usd), 0)                                          AS total_net_revenue_usd,
    COUNT(so_id)                                                            AS total_orders,
    ROUND(AVG(total_amount_usd), 2)                                        AS avg_order_value_usd,

    -- Delivery KPIs
    ROUND(SUM(CASE WHEN on_time_delivery = true THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS otd_rate_pct,
    ROUND(AVG(delay_days), 2)                                              AS avg_delay_days,
    ROUND(SUM(CASE WHEN return_flag = true THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS return_rate_pct,

    -- Period
    MIN(order_date)  AS data_from,
    MAX(order_date)  AS data_to,
    CURRENT_TIMESTAMP() AS calculated_at

FROM {SILVER_DB}.fact_sales_orders
""")

write_gold(kpis, "gold_kpi_summary")

# COMMAND ----------
# MAGIC %md ## Gold Layer Validation

# COMMAND ----------
gold_tables = [
    "dim_date", "gold_monthly_revenue", "gold_supplier_scorecard",
    "gold_inventory_health", "gold_carrier_performance",
    "gold_product_revenue", "gold_order_fulfillment", "gold_kpi_summary"
]

print("\n" + "="*60)
print("GOLD LAYER — FINAL VALIDATION")
print("="*60)
for tbl in gold_tables:
    df = spark.table(f"{GOLD_DB}.{tbl}")
    print(f"  {tbl:<35} {df.count():>8,} rows  |  {len(df.columns)} cols")

# COMMAND ----------
# MAGIC %md
# MAGIC ## ✅ Gold Layer Complete
# MAGIC 
# MAGIC | Gold Table | Power BI Usage |
# MAGIC |-----------|---------------|
# MAGIC | dim_date | Time intelligence slicers |
# MAGIC | gold_monthly_revenue | Revenue trend line chart |
# MAGIC | gold_supplier_scorecard | Supplier ranking table |
# MAGIC | gold_inventory_health | Inventory heatmap |
# MAGIC | gold_carrier_performance | Carrier comparison |
# MAGIC | gold_product_revenue | Product mix analysis |
# MAGIC | gold_order_fulfillment | Fulfillment funnel |
# MAGIC | gold_kpi_summary | Dashboard KPI cards |
# MAGIC 
# MAGIC **Next Step:** Connect Power BI via Databricks SQL Warehouse (JDBC/ODBC)
