# Databricks notebook source
# MAGIC %md
# MAGIC # 🥈 Silver Layer — Cleaning & Standardization
# MAGIC **Pipeline:** Supply Chain Lakehouse  
# MAGIC **Layer:** Silver (Cleaned, Deduplicated, Type-safe)  
# MAGIC **Reads from:** supply_chain_bronze  
# MAGIC **Writes to:** supply_chain_silver

# COMMAND ----------
BRONZE_DB = "supply_chain_bronze"
SILVER_DB = "supply_chain_silver"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {SILVER_DB}")
spark.sql(f"USE {SILVER_DB}")
print(f"✓ Database ready: {SILVER_DB}")

# COMMAND ----------
from pyspark.sql import functions as F
from pyspark.sql.types import *
from delta.tables import DeltaTable

def write_silver(df, table_name: str, merge_key: str):
    """
    Upsert into Silver Delta table using merge key.
    Ensures idempotency — safe to re-run.
    """
    target_table = f"{SILVER_DB}.{table_name}"
    
    # Add Silver metadata
    df = (df
          .withColumn("_silver_processed_at", F.current_timestamp())
          .withColumn("_silver_date", F.current_date()))
    
    if spark.catalog.tableExists(target_table):
        delta_tbl = DeltaTable.forName(spark, target_table)
        (delta_tbl.alias("target")
         .merge(df.alias("source"), f"target.{merge_key} = source.{merge_key}")
         .whenMatchedUpdateAll()
         .whenNotMatchedInsertAll()
         .execute())
    else:
        (df.write
           .format("delta")
           .mode("overwrite")
           .option("overwriteSchema", "true")
           .saveAsTable(target_table))
    
    count = spark.table(target_table).count()
    print(f"✓ {target_table}: {count:,} rows")

# COMMAND ----------
# MAGIC %md ## 1. Clean Suppliers

# COMMAND ----------
suppliers_raw = spark.table(f"{BRONZE_DB}.raw_suppliers")

suppliers_clean = (suppliers_raw
    # Drop Bronze metadata
    .drop("_ingested_at", "_source_file", "_ingestion_date", "_batch_id")
    # Standardize strings
    .withColumn("supplier_name", F.trim(F.initcap(F.col("supplier_name"))))
    .withColumn("country",       F.trim(F.upper(F.col("country"))))
    .withColumn("city",          F.trim(F.initcap(F.col("city"))))
    .withColumn("payment_terms", F.trim(F.upper(F.col("payment_terms"))))
    .withColumn("category",      F.trim(F.col("category")))
    # Cast types
    .withColumn("rating",             F.col("rating").cast(DoubleType()))
    .withColumn("lead_time_days",     F.col("lead_time_days").cast(IntegerType()))
    .withColumn("annual_spend_usd",   F.col("annual_spend_usd").cast(LongType()))
    .withColumn("is_active",          F.col("is_active").cast(BooleanType()))
    .withColumn("contract_start",     F.to_date("contract_start", "yyyy-MM-dd"))
    # Data quality filters
    .filter(F.col("supplier_id").isNotNull())
    .filter(F.col("rating").between(0, 5))
    .filter(F.col("lead_time_days") > 0)
    # Deduplicate
    .dropDuplicates(["supplier_id"])
)

write_silver(suppliers_clean, "dim_suppliers", "supplier_id")

# COMMAND ----------
# MAGIC %md ## 2. Clean Warehouses

# COMMAND ----------
warehouses_raw = spark.table(f"{BRONZE_DB}.raw_warehouses")

warehouses_clean = (warehouses_raw
    .drop("_ingested_at", "_source_file", "_ingestion_date", "_batch_id")
    .withColumn("city",    F.trim(F.initcap(F.col("city"))))
    .withColumn("region",  F.trim(F.col("region")))
    .withColumn("country", F.trim(F.upper(F.col("country"))))
    .withColumn("capacity_sqft", F.col("capacity_sqft").cast(IntegerType()))
    .withColumn("lat",  F.col("lat").cast(DoubleType()))
    .withColumn("lon",  F.col("lon").cast(DoubleType()))
    .filter(F.col("warehouse_id").isNotNull())
    .dropDuplicates(["warehouse_id"])
)

write_silver(warehouses_clean, "dim_warehouses", "warehouse_id")

# COMMAND ----------
# MAGIC %md ## 3. Clean Carriers

# COMMAND ----------
carriers_raw = spark.table(f"{BRONZE_DB}.raw_carriers")

carriers_clean = (carriers_raw
    .drop("_ingested_at", "_source_file", "_ingestion_date", "_batch_id")
    .withColumn("name",               F.trim(F.col("name")))
    .withColumn("type",               F.trim(F.upper(F.col("type"))))
    .withColumn("reliability_score",  F.col("reliability_score").cast(DoubleType()))
    .filter(F.col("carrier_id").isNotNull())
    .filter(F.col("reliability_score").between(0, 1))
    .dropDuplicates(["carrier_id"])
)

write_silver(carriers_clean, "dim_carriers", "carrier_id")

# COMMAND ----------
# MAGIC %md ## 4. Clean Products

# COMMAND ----------
products_raw = spark.table(f"{BRONZE_DB}.raw_products")

products_clean = (products_raw
    .drop("_ingested_at", "_source_file", "_ingestion_date", "_batch_id")
    .withColumn("product_name",     F.trim(F.col("product_name")))
    .withColumn("category",         F.trim(F.col("category")))
    .withColumn("sku",              F.trim(F.upper(F.col("sku"))))
    .withColumn("unit_cost_usd",    F.col("unit_cost_usd").cast(DoubleType()))
    .withColumn("unit_price_usd",   F.col("unit_price_usd").cast(DoubleType()))
    .withColumn("weight_kg",        F.col("weight_kg").cast(DoubleType()))
    .withColumn("volume_cbm",       F.col("volume_cbm").cast(DoubleType()))
    .withColumn("reorder_point",    F.col("reorder_point").cast(IntegerType()))
    .withColumn("reorder_qty",      F.col("reorder_qty").cast(IntegerType()))
    .withColumn("shelf_life_days",  F.col("shelf_life_days").cast(IntegerType()))
    .withColumn("is_hazardous",     F.col("is_hazardous").cast(BooleanType()))
    # Derived column: gross margin %
    .withColumn("gross_margin_pct",
        F.round((F.col("unit_price_usd") - F.col("unit_cost_usd")) / F.col("unit_price_usd") * 100, 2))
    .filter(F.col("product_id").isNotNull())
    .filter(F.col("unit_cost_usd") > 0)
    .filter(F.col("unit_price_usd") >= F.col("unit_cost_usd"))
    .dropDuplicates(["product_id"])
)

write_silver(products_clean, "dim_products", "product_id")

# COMMAND ----------
# MAGIC %md ## 5. Clean Purchase Orders

# COMMAND ----------
po_raw = spark.table(f"{BRONZE_DB}.raw_purchase_orders")

po_clean = (po_raw
    .drop("_ingested_at", "_source_file", "_ingestion_date", "_batch_id")
    .withColumn("order_date",             F.to_date("order_date", "yyyy-MM-dd"))
    .withColumn("expected_delivery_date", F.to_date("expected_delivery_date", "yyyy-MM-dd"))
    .withColumn("actual_delivery_date",   F.to_date("actual_delivery_date", "yyyy-MM-dd"))
    .withColumn("total_amount_usd",       F.col("total_amount_usd").cast(DoubleType()))
    .withColumn("delay_days",             F.col("delay_days").cast(IntegerType()))
    .withColumn("quality_check_passed",   F.col("quality_check_passed").cast(BooleanType()))
    .withColumn("status",                 F.trim(F.col("status")))
    .withColumn("payment_status",         F.trim(F.col("payment_status")))
    .withColumn("incoterms",              F.trim(F.upper(F.col("incoterms"))))
    # Derived: was it late?
    .withColumn("is_late",
        F.when(F.col("actual_delivery_date") > F.col("expected_delivery_date"), True)
         .otherwise(False))
    # Derived: order year-month for partitioning
    .withColumn("order_year_month", F.date_format(F.col("order_date"), "yyyy-MM"))
    .filter(F.col("po_id").isNotNull())
    .filter(F.col("total_amount_usd") > 0)
    .dropDuplicates(["po_id"])
)

write_silver(po_clean, "fact_purchase_orders", "po_id")

# COMMAND ----------
# MAGIC %md ## 6. Clean PO Line Items

# COMMAND ----------
pol_raw = spark.table(f"{BRONZE_DB}.raw_po_line_items")

pol_clean = (pol_raw
    .drop("_ingested_at", "_source_file", "_ingestion_date", "_batch_id")
    .withColumn("quantity",           F.col("quantity").cast(IntegerType()))
    .withColumn("unit_cost_usd",      F.col("unit_cost_usd").cast(DoubleType()))
    .withColumn("total_cost_usd",     F.col("total_cost_usd").cast(DoubleType()))
    .withColumn("quantity_received",  F.col("quantity_received").cast(IntegerType()))
    # Derived: fill rate
    .withColumn("fill_rate_pct",
        F.round(F.col("quantity_received") / F.col("quantity") * 100, 2))
    .filter(F.col("line_id").isNotNull())
    .filter(F.col("quantity") > 0)
    .dropDuplicates(["line_id"])
)

write_silver(pol_clean, "fact_po_line_items", "line_id")

# COMMAND ----------
# MAGIC %md ## 7. Clean Shipments

# COMMAND ----------
shp_raw = spark.table(f"{BRONZE_DB}.raw_shipments")

shp_clean = (shp_raw
    .drop("_ingested_at", "_source_file", "_ingestion_date", "_batch_id")
    .withColumn("ship_date",         F.to_date("ship_date", "yyyy-MM-dd"))
    .withColumn("estimated_arrival", F.to_date("estimated_arrival", "yyyy-MM-dd"))
    .withColumn("actual_arrival",    F.to_date("actual_arrival", "yyyy-MM-dd"))
    .withColumn("shipping_cost_usd", F.col("shipping_cost_usd").cast(DoubleType()))
    .withColumn("weight_kg",         F.col("weight_kg").cast(DoubleType()))
    .withColumn("volume_cbm",        F.col("volume_cbm").cast(DoubleType()))
    .withColumn("customs_cleared",   F.col("customs_cleared").cast(BooleanType()))
    .withColumn("damage_reported",   F.col("damage_reported").cast(BooleanType()))
    .withColumn("mode",              F.trim(F.upper(F.col("mode"))))
    .withColumn("status",            F.trim(F.col("status")))
    # Derived: transit days
    .withColumn("actual_transit_days",
        F.datediff(F.col("actual_arrival"), F.col("ship_date")))
    .withColumn("estimated_transit_days",
        F.datediff(F.col("estimated_arrival"), F.col("ship_date")))
    # Derived: shipment on time?
    .withColumn("is_on_time",
        F.when(F.col("actual_arrival") <= F.col("estimated_arrival"), True)
         .otherwise(False))
    .filter(F.col("shipment_id").isNotNull())
    .dropDuplicates(["shipment_id"])
)

write_silver(shp_clean, "fact_shipments", "shipment_id")

# COMMAND ----------
# MAGIC %md ## 8. Clean Sales Orders

# COMMAND ----------
so_raw = spark.table(f"{BRONZE_DB}.raw_sales_orders")

so_clean = (so_raw
    .drop("_ingested_at", "_source_file", "_ingestion_date", "_batch_id")
    .withColumn("order_date",             F.to_date("order_date", "yyyy-MM-dd"))
    .withColumn("promised_delivery_date", F.to_date("promised_delivery_date", "yyyy-MM-dd"))
    .withColumn("actual_delivery_date",   F.to_date("actual_delivery_date", "yyyy-MM-dd"))
    .withColumn("total_amount_usd",       F.col("total_amount_usd").cast(DoubleType()))
    .withColumn("discount_pct",           F.col("discount_pct").cast(DoubleType()))
    .withColumn("on_time_delivery",       F.col("on_time_delivery").cast(BooleanType()))
    .withColumn("return_flag",            F.col("return_flag").cast(BooleanType()))
    .withColumn("delay_days",             F.col("delay_days").cast(IntegerType()))
    .withColumn("status",                 F.trim(F.col("status")))
    .withColumn("priority",               F.trim(F.col("priority")))
    .withColumn("sales_channel",          F.trim(F.col("sales_channel")))
    # Derived columns
    .withColumn("order_year",   F.year("order_date"))
    .withColumn("order_month",  F.month("order_date"))
    .withColumn("order_quarter",F.quarter("order_date"))
    .withColumn("order_week",   F.weekofyear("order_date"))
    .withColumn("net_amount_usd",
        F.round(F.col("total_amount_usd") * (1 - F.col("discount_pct")), 2))
    .filter(F.col("so_id").isNotNull())
    .filter(F.col("total_amount_usd") > 0)
    .dropDuplicates(["so_id"])
)

write_silver(so_clean, "fact_sales_orders", "so_id")

# COMMAND ----------
# MAGIC %md ## 9. Clean SO Line Items

# COMMAND ----------
sol_raw = spark.table(f"{BRONZE_DB}.raw_so_line_items")

sol_clean = (sol_raw
    .drop("_ingested_at", "_source_file", "_ingestion_date", "_batch_id")
    .withColumn("quantity",         F.col("quantity").cast(IntegerType()))
    .withColumn("unit_price_usd",   F.col("unit_price_usd").cast(DoubleType()))
    .withColumn("total_price_usd",  F.col("total_price_usd").cast(DoubleType()))
    .withColumn("discount_pct",     F.col("discount_pct").cast(DoubleType()))
    .withColumn("net_revenue_usd",
        F.round(F.col("total_price_usd") * (1 - F.col("discount_pct")), 2))
    .filter(F.col("sol_id").isNotNull())
    .filter(F.col("quantity") > 0)
    .dropDuplicates(["sol_id"])
)

write_silver(sol_clean, "fact_so_line_items", "sol_id")

# COMMAND ----------
# MAGIC %md ## 10. Clean Inventory

# COMMAND ----------
inv_raw = spark.table(f"{BRONZE_DB}.raw_inventory")

inv_clean = (inv_raw
    .drop("_ingested_at", "_source_file", "_ingestion_date", "_batch_id")
    .withColumn("snapshot_date",       F.to_date("snapshot_date", "yyyy-MM-dd"))
    .withColumn("last_restock_date",   F.to_date("last_restock_date", "yyyy-MM-dd"))
    .withColumn("quantity_on_hand",    F.col("quantity_on_hand").cast(IntegerType()))
    .withColumn("quantity_reserved",   F.col("quantity_reserved").cast(IntegerType()))
    .withColumn("quantity_in_transit", F.col("quantity_in_transit").cast(IntegerType()))
    # Derived: available to promise (ATP)
    .withColumn("quantity_available",
        F.col("quantity_on_hand") - F.col("quantity_reserved"))
    # Derived: days since restock
    .withColumn("days_since_restock",
        F.datediff(F.col("snapshot_date"), F.col("last_restock_date")))
    .filter(F.col("snapshot_id").isNotNull())
    .filter(F.col("quantity_on_hand") >= 0)
    .dropDuplicates(["snapshot_id"])
)

write_silver(inv_clean, "fact_inventory", "snapshot_id")

# COMMAND ----------
# MAGIC %md ## Silver Layer Validation

# COMMAND ----------
silver_tables = [
    "dim_suppliers", "dim_warehouses", "dim_carriers", "dim_products",
    "fact_purchase_orders", "fact_po_line_items", "fact_shipments",
    "fact_sales_orders", "fact_so_line_items", "fact_inventory"
]

print("\n" + "="*60)
print("SILVER LAYER VALIDATION")
print("="*60)
for tbl in silver_tables:
    df = spark.table(f"{SILVER_DB}.{tbl}")
    nulls = {c: df.filter(F.col(c).isNull()).count() for c in df.columns[:3]}
    print(f"\n{tbl}")
    print(f"  Rows: {df.count():,}")
    print(f"  Cols: {len(df.columns)}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## ✅ Silver Layer Complete
# MAGIC - All types cast correctly
# MAGIC - Duplicates removed
# MAGIC - Derived columns added
# MAGIC - Null filters applied
# MAGIC 
# MAGIC **Next Step:** Run `03_gold_aggregations.py`
