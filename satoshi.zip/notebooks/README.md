# 🏭 Supply Chain Lakehouse — End-to-End Data Engineering Project

## Architecture

```
CSV Files (46k rows)
      ↓
Azure Data Factory / Manual Upload
      ↓
Delta Lake — BRONZE (raw_*)          ← supply_chain_bronze DB
      ↓
Databricks Notebooks — PySpark
      ↓
Delta Lake — SILVER (dim_*, fact_*)  ← supply_chain_silver DB
      ↓
dbt Core — SQL Transformations + Tests
      ↓
Delta Lake — GOLD (gold_*)           ← supply_chain_gold DB
      ↓
Databricks SQL Warehouse
      ↓
Power BI DirectQuery — Live Dashboards
```

---

## Dataset (46,018 rows across 10 tables)

| File | Rows | Description |
|------|------|-------------|
| suppliers.csv | 40 | Supplier master — 7 countries, 7 categories |
| warehouses.csv | 5 | KHI, LHR, ISB, DXB, Mumbai |
| carriers.csv | 7 | DHL, Maersk, FedEx, TCS, Cosco etc |
| products.csv | 39 | SKUs across 7 categories |
| inventory.csv | 7,800 | Monthly snapshots per warehouse/product |
| purchase_orders.csv | 3,000 | 2022–2024, with delays and quality checks |
| po_line_items.csv | 11,683 | PO detail lines |
| shipments.csv | 2,399 | Tracking with transit days |
| sales_orders.csv | 4,619 | Customer orders with OTD flag |
| so_line_items.csv | 16,426 | Order detail lines |

---

## Notebooks — Run in Order

```
01_bronze_ingestion.py   → Ingest CSVs → Bronze Delta
02_silver_cleaning.py    → Clean + cast types → Silver Delta
03_gold_aggregations.py  → Business KPIs → Gold Delta (Star Schema)
04_optimize.py           → OPTIMIZE + ZORDER for fast BI queries
```

---

## dbt Models

```
models/
  staging/
    stg_suppliers.sql
    stg_purchase_orders.sql
    stg_sales_orders.sql
  marts/
    gold_supplier_scorecard.sql   ← composite supplier score
    gold_monthly_revenue.sql
    gold_inventory_health.sql
schema.yml                        ← all tests defined here
```

**Run dbt:**
```bash
pip install dbt-databricks
dbt deps
dbt run
dbt test
dbt docs generate && dbt docs serve
```

---

## Gold Tables → Power BI Mapping

| Gold Table | Dashboard Visual |
|-----------|-----------------|
| gold_kpi_summary | KPI cards (Revenue, OTD %, Returns) |
| gold_monthly_revenue | Revenue trend line chart |
| gold_supplier_scorecard | Supplier ranking matrix |
| gold_inventory_health | Stock status heatmap |
| gold_carrier_performance | Carrier comparison bar chart |
| gold_product_revenue | Category revenue treemap |
| gold_order_fulfillment | Fulfillment funnel |
| dim_date | Time slicer (year/quarter/month) |

---

## Key KPIs This Project Tracks

- **OTD Rate** — On-Time Delivery %
- **Supplier Score** — Composite (OTD 35% + Quality 35% + Fill Rate 30%)
- **Inventory Health** — Stock status per warehouse
- **Carrier Cost per KG** — Shipping efficiency
- **Gross Margin %** — Per product/category
- **Return Rate %** — Customer order returns
- **PO Delay Days** — Avg supplier delay

---

## How to Run in Databricks

1. Upload all CSVs to ADLS Gen2 → `/mnt/supply_chain/landing/`
2. Import notebooks from this folder into Databricks Workspace
3. Run notebooks 01 → 02 → 03 → 04 in order
4. (Optional) Import `databricks_workflow.json` as a Workflow Job for scheduling
5. Connect Power BI → Databricks SQL Warehouse → DirectQuery on `supply_chain_gold`

---

## Orchestration

Import `databricks_workflow.json` into Databricks Workflows.  
It runs the full pipeline daily at 6am PKT.

**Pipeline DAG:**
```
bronze_ingestion → silver_cleaning → gold_aggregations → dbt_tests → optimize
```
