# Databricks notebook source
# MAGIC %md
# MAGIC # ⚡ Optimize Delta Tables for Power BI Performance
# MAGIC Run after Gold layer build.  
# MAGIC OPTIMIZE compacts small files. ZORDER sorts data for fast filtering.

# COMMAND ----------
GOLD_DB = "supply_chain_gold"

# COMMAND ----------
# MAGIC %md ## OPTIMIZE + ZORDER — Gold Tables

# COMMAND ----------
optimizations = [
    # (table_name, zorder_columns)
    ("gold_monthly_revenue",    "order_year, order_month, warehouse_id"),
    ("gold_supplier_scorecard", "supplier_tier, category, country"),
    ("gold_inventory_health",   "warehouse_id, stock_status, category"),
    ("gold_carrier_performance","type, carrier_id"),
    ("gold_product_revenue",    "order_year, order_quarter, category"),
    ("gold_order_fulfillment",  "order_year, fulfillment_status, warehouse_id"),
]

for table_name, zorder_cols in optimizations:
    full_name = f"{GOLD_DB}.{table_name}"
    print(f"\n⚡ Optimizing {full_name}...")
    spark.sql(f"OPTIMIZE {full_name} ZORDER BY ({zorder_cols})")
    print(f"   ✓ Done")

# COMMAND ----------
# MAGIC %md ## Vacuum Old Delta Files (7 day retention)

# COMMAND ----------
for table_name, _ in optimizations:
    full_name = f"{GOLD_DB}.{table_name}"
    spark.sql(f"VACUUM {full_name} RETAIN 168 HOURS")
    print(f"✓ Vacuumed: {full_name}")

# COMMAND ----------
# MAGIC %md ## Analyze Tables — Update Statistics for Query Optimizer

# COMMAND ----------
for table_name, _ in optimizations:
    full_name = f"{GOLD_DB}.{table_name}"
    spark.sql(f"ANALYZE TABLE {full_name} COMPUTE STATISTICS")
    print(f"✓ Statistics updated: {full_name}")

print("\n✅ All optimizations complete — Power BI queries will be fast!")
