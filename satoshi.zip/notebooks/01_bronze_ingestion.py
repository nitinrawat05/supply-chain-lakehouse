# Databricks notebook source
# MAGIC %md
# MAGIC # 🥉 Bronze Layer — Raw Ingestion
# MAGIC **Pipeline:** Supply Chain Lakehouse  
# MAGIC **Layer:** Bronze (Raw, Immutable)  
# MAGIC **Purpose:** Ingest CSV files into Delta tables as-is. No transformation. Add metadata only.

# COMMAND ----------
# MAGIC %md ## Setup — Mount Point & Config

# COMMAND ----------
# CONFIG — update these to match your Databricks environment
STORAGE_ACCOUNT = "your_storage_account"   # Azure ADLS Gen2
CONTAINER       = "supply-chain"
MOUNT_POINT     = "/mnt/supply_chain"

# Database
BRONZE_DB = "supply_chain_bronze"

# COMMAND ----------
# Create Bronze database
spark.sql(f"CREATE DATABASE IF NOT EXISTS {BRONZE_DB}")
spark.sql(f"USE {BRONZE_DB}")
print(f"✓ Database ready: {BRONZE_DB}")

# COMMAND ----------
# MAGIC %md ## Helper — Ingest CSV to Bronze Delta

# COMMAND ----------
from pyspark.sql import functions as F
from pyspark.sql.types import *
from datetime import datetime

def ingest_to_bronze(file_name: str, table_name: str):
    """
    Read CSV from landing zone.
    Add ingestion metadata columns.
    Write to Bronze Delta table (append + schema evolution).
    """
    source_path = f"{MOUNT_POINT}/landing/{file_name}"
    target_table = f"{BRONZE_DB}.{table_name}"
    
    print(f"\n📥 Ingesting: {file_name} → {target_table}")
    
    df = (spark.read
          .option("header", "true")
          .option("inferSchema", "true")
          .option("multiLine", "true")
          .option("escape", '"')
          .csv(source_path))
    
    # Add Bronze metadata columns
    df = (df
          .withColumn("_ingested_at",    F.current_timestamp())
          .withColumn("_source_file",    F.lit(file_name))
          .withColumn("_ingestion_date", F.current_date())
          .withColumn("_batch_id",       F.lit(datetime.now().strftime("%Y%m%d_%H%M%S"))))
    
    (df.write
       .format("delta")
       .mode("append")
       .option("mergeSchema", "true")
       .saveAsTable(target_table))
    
    count = spark.table(target_table).count()
    print(f"   ✓ {count:,} rows in {target_table}")
    return count

# COMMAND ----------
# MAGIC %md ## Ingest All Tables

# COMMAND ----------
tables = {
    "suppliers.csv":       "raw_suppliers",
    "warehouses.csv":      "raw_warehouses",
    "carriers.csv":        "raw_carriers",
    "products.csv":        "raw_products",
    "inventory.csv":       "raw_inventory",
    "purchase_orders.csv": "raw_purchase_orders",
    "po_line_items.csv":   "raw_po_line_items",
    "shipments.csv":       "raw_shipments",
    "sales_orders.csv":    "raw_sales_orders",
    "so_line_items.csv":   "raw_so_line_items",
}

results = {}
for file_name, table_name in tables.items():
    results[table_name] = ingest_to_bronze(file_name, table_name)

# COMMAND ----------
# MAGIC %md ## Validate Bronze Layer

# COMMAND ----------
print("\n" + "="*60)
print("BRONZE LAYER VALIDATION")
print("="*60)

for table_name in tables.values():
    df = spark.table(f"{BRONZE_DB}.{table_name}")
    print(f"\n{table_name}")
    print(f"  Rows    : {df.count():,}")
    print(f"  Columns : {len(df.columns)}")
    print(f"  Metadata: _ingested_at, _source_file, _ingestion_date, _batch_id")

# COMMAND ----------
# MAGIC %md ## Enable Delta Features on Bronze Tables

# COMMAND ----------
for table_name in tables.values():
    full_name = f"{BRONZE_DB}.{table_name}"
    # Enable Change Data Feed for downstream consumption
    spark.sql(f"""
        ALTER TABLE {full_name}
        SET TBLPROPERTIES (
            delta.enableChangeDataFeed = true,
            delta.autoOptimize.optimizeWrite = true,
            delta.autoOptimize.autoCompact = true
        )
    """)

print("✓ Delta optimizations enabled on all Bronze tables")

# COMMAND ----------
# MAGIC %md ## Bronze Layer Summary
# MAGIC 
# MAGIC | Table | Description |
# MAGIC |-------|-------------|
# MAGIC | raw_suppliers | Supplier master data |
# MAGIC | raw_warehouses | Warehouse locations |
# MAGIC | raw_carriers | Shipping carriers |
# MAGIC | raw_products | Product catalog |
# MAGIC | raw_inventory | Inventory snapshots |
# MAGIC | raw_purchase_orders | PO headers |
# MAGIC | raw_po_line_items | PO line details |
# MAGIC | raw_shipments | Shipment tracking |
# MAGIC | raw_sales_orders | Customer orders |
# MAGIC | raw_so_line_items | Order line details |
# MAGIC 
# MAGIC **Next Step:** Run `02_silver_cleaning.py`
